package com.example.friendbook;

import java.util.Locale;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class Lifemovies extends Activity {
ImageButton tamil1,tamil2,tamil3,hindi1,hindi2,hindi3,eng1,eng2,eng3,mala1,mala2,mala3;
DataBaseHelper sqlite;
SQLiteDatabase db;
String database="Friendbook.db";
boolean dbfound=true;
Cursor cursor;
String registers,name,style;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_lifemovies);
		Intent in=getIntent();
		name=in.getStringExtra("name");
		style=in.getStringExtra("movie");
		tamil1=(ImageButton)findViewById(R.id.tamil1);
		tamil2=(ImageButton)findViewById(R.id.tamil2);
		tamil3=(ImageButton)findViewById(R.id.tamil3);
		hindi1=(ImageButton)findViewById(R.id.hindi1);
		hindi2=(ImageButton)findViewById(R.id.hindi2);
		hindi3=(ImageButton)findViewById(R.id.hindi3);
		eng1=(ImageButton)findViewById(R.id.eng1);
		eng2=(ImageButton)findViewById(R.id.eng2);
		eng3=(ImageButton)findViewById(R.id.eng3);
		mala1=(ImageButton)findViewById(R.id.mala1);
		mala2=(ImageButton)findViewById(R.id.mala2);
		mala3=(ImageButton)findViewById(R.id.mala3);
		
		tamil1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				try{
					db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
					db.setVersion(1);
					db.setLocale(Locale.getDefault());
					db.setLockingEnabled(true);
					dbfound=true;
								
				}catch(Exception e){
					e.printStackTrace();
					//display("Error DataBase");
				}
			String updateing="update regsiter set lifestyle='"+style+"',lifeimage='"+"t1"+"' where username='"+name+"'";
			db.execSQL(updateing);
				db.close();
				Toast.makeText(getBaseContext(), "Update Successfully",Toast.LENGTH_SHORT).show();
			}
		});
tamil2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				try{
					db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
					db.setVersion(1);
					db.setLocale(Locale.getDefault());
					db.setLockingEnabled(true);
					dbfound=true;
								
				}catch(Exception e){
					e.printStackTrace();
					//display("Error DataBase");
				}
			String updateing="update regsiter set lifestyle='"+style+"',lifeimage='"+"t2"+"' where username='"+name+"'";
			db.execSQL(updateing);
				db.close();
				Toast.makeText(getBaseContext(), "Update Successfully",Toast.LENGTH_SHORT).show();
	
			}
		});
tamil3.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		try{
			db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound=true;
						
		}catch(Exception e){
			e.printStackTrace();
			//display("Error DataBase");
		}
	String updateing="update regsiter set lifestyle='"+style+"',lifeimage='"+"t3"+"' where username='"+name+"'";
	db.execSQL(updateing);
		db.close();
		Toast.makeText(getBaseContext(), "Update Successfully",Toast.LENGTH_SHORT).show();

	}
});
hindi1.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		try{
			db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound=true;
						
		}catch(Exception e){
			e.printStackTrace();
			//display("Error DataBase");
		}
	String updateing="update regsiter set lifestyle='"+style+"',lifeimage='"+"h1"+"' where username='"+name+"'";
	db.execSQL(updateing);
		db.close();
		Toast.makeText(getBaseContext(), "Update Successfully",Toast.LENGTH_SHORT).show();

	}
});
hindi2.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		try{
			db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound=true;
						
		}catch(Exception e){
			e.printStackTrace();
			//display("Error DataBase");
		}
	String updateing="update regsiter set lifestyle='"+style+"',lifeimage='"+"h2"+"' where username='"+name+"'";
	db.execSQL(updateing);
		db.close();
		Toast.makeText(getBaseContext(), "Update Successfully",Toast.LENGTH_SHORT).show();

	}
});
hindi3.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		try{
			db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound=true;
						
		}catch(Exception e){
			e.printStackTrace();
			//display("Error DataBase");
		}
	String updateing="update regsiter set lifestyle='"+style+"',lifeimage='"+"h3"+"' where username='"+name+"'";
	db.execSQL(updateing);
		db.close();
		Toast.makeText(getBaseContext(), "Update Successfully",Toast.LENGTH_SHORT).show();

	}
});
eng1.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		try{
			db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound=true;
						
		}catch(Exception e){
			e.printStackTrace();
			//display("Error DataBase");
		}
	String updateing="update regsiter set lifestyle='"+style+"',lifeimage='"+"e1"+"' where username='"+name+"'";
	db.execSQL(updateing);
		db.close();
		Toast.makeText(getBaseContext(), "Update Successfully",Toast.LENGTH_SHORT).show();

	}
});
eng2.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		try{
			db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound=true;
						
		}catch(Exception e){
			e.printStackTrace();
			//display("Error DataBase");
		}
	String updateing="update regsiter set lifestyle='"+style+"',lifeimage='"+"e2"+"' where username='"+name+"'";
	db.execSQL(updateing);
		db.close();
		Toast.makeText(getBaseContext(), "Update Successfully",Toast.LENGTH_SHORT).show();

	}
});
eng3.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		try{
			db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound=true;
						
		}catch(Exception e){
			e.printStackTrace();
			//display("Error DataBase");
		}
	String updateing="update regsiter set lifestyle='"+style+"',lifeimage='"+"e3"+"' where username='"+name+"'";
	db.execSQL(updateing);
		db.close();
		Toast.makeText(getBaseContext(), "Update Successfully",Toast.LENGTH_SHORT).show();

	}
});
mala1.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		try{
			db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound=true;
						
		}catch(Exception e){
			e.printStackTrace();
			//display("Error DataBase");
		}
	String updateing="update regsiter set lifestyle='"+style+"',lifeimage='"+"m1"+"' where username='"+name+"'";
	db.execSQL(updateing);
		db.close();
		Toast.makeText(getBaseContext(), "Update Successfully",Toast.LENGTH_SHORT).show();

	}
});
mala2.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		try{
			db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound=true;
						
		}catch(Exception e){
			e.printStackTrace();
			//display("Error DataBase");
		}
	String updateing="update regsiter set lifestyle='"+style+"',lifeimage='"+"m2"+"' where username='"+name+"'";
	db.execSQL(updateing);
		db.close();
		Toast.makeText(getBaseContext(), "Update Successfully",Toast.LENGTH_SHORT).show();

	}
});
mala3.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		try{
			db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound=true;
						
		}catch(Exception e){
			e.printStackTrace();
			//display("Error DataBase");
		}
	String updateing="update regsiter set lifestyle='"+style+"',lifeimage='"+"m3"+"' where username='"+name+"'";
	db.execSQL(updateing);
		db.close();
		Toast.makeText(getBaseContext(), "Update Successfully",Toast.LENGTH_SHORT).show();

	}
});

		
	}

	
}
