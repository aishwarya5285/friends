package com.example.friendbook;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class Friendview extends Activity {
	ListView list1;
	
	String lifestyle;
	String username;
	ArrayList<HashMap<String, String>> myhashlist=new ArrayList<HashMap<String,String>>();
	DataBaseHelper sqlite;
	SQLiteDatabase db;
	String database="Friendbook.db";
	boolean dbfound=true;
	Cursor cursor;
	String user,lifestyleimage;
	String latitude,longitude; 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_friendview);
		Intent in =getIntent();
		username=in.getStringExtra("name");
		
		list1=(ListView)findViewById(R.id.listView1);
		sqlite=new DataBaseHelper(getApplicationContext());
		sqlite.getWritableDatabase();
		try{
			db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound=true;
			
		}catch(Exception e){
			e.printStackTrace();
			//display("Error DataBase");
		}
		cursor=db.rawQuery("select * from regsiter where username='"+username+"'",null);
		  cursor.moveToFirst();
		
		    while (!cursor.isAfterLast()) {
		
		   lifestyleimage=cursor.getString(6);
		   
		
		    
		   
		      cursor.moveToNext();
		  
		    
		    }
		    cursor.close();
		    db.close();  
		myhashlist=sqlite.alist(lifestyleimage,username);
		Log.e("Values :   ",""+myhashlist );
		list1.setAdapter(new Userlist(getApplicationContext(), myhashlist));
		list1.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				TextView aname=(TextView)view.findViewById(R.id.textView3);
				final String name=aname.getText().toString();
				System.out.println(name);
				
				String n1[]=name.split(":");
				final String names=n1[1];
				Log.e("Values :   ",""+names );
				try{
					db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
					db.setVersion(1);
					db.setLocale(Locale.getDefault());
					db.setLockingEnabled(true);
					dbfound=true;
					
				
				cursor=db.rawQuery("select * from regsiter where username='"+names.trim()+"'",null);
				  cursor.moveToFirst();
				
				    while (!cursor.isAfterLast()) {
				
				   latitude=cursor.getString(7);
				   longitude=cursor.getString(8);
				
				    System.out.println(latitude);
				    System.out.println(longitude);
					Log.e("Values :   ",""+latitude );
					
				      cursor.moveToNext();
				  
				    
				    }
				    cursor.close();
				}catch(Exception e){
					e.printStackTrace();
					//display("Error DataBase");
				}
				AlertDialog.Builder aBuilder=new AlertDialog.Builder(Friendview.this);
				aBuilder.setMessage("Perform action");
				aBuilder.setTitle("FRIEND LOCATION VIEW AND CHAT");
				aBuilder.setPositiveButton("CHAT",new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						Intent in=new Intent(getApplicationContext(),BluetoothChat.class);
						startActivity(in);
						
					}
				});
				aBuilder.setNegativeButton("LOCATION VIEW",new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
  						Log.e("Values :   ",""+names );
						
						    Double myLongitude = Double.valueOf(longitude.trim());
						    Double myLatitude = Double.valueOf(latitude.trim());
						    //using google maps you will create a map setting lat & long.     
						    String urlAddress = "http://maps.google.com/maps?q="+ myLatitude +"," + myLongitude +"&iwloc=A&hl=es";     
						    //second option:: urlAddress = "http://maps.googleapis.com/maps/api/streetview?size=500x500&location=" + myLatitude + "," + myLongitude + "&fov=90&heading=235&pitch=10&sensor=false";
						    //third option:: urlAddress = "geo:<" + myLatitude + ">,<" + myLongitude +">?q=<" + latitude + ">,<" + longitude +">(this is my currently location)"                                
						    Intent maps = new Intent(Intent.ACTION_VIEW, Uri.parse(urlAddress));
						    startActivity(maps);
//						
					}
				});
			AlertDialog all=aBuilder.create();
			all.show();
			}
		});
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.friendview, menu);
		return true;
	}

	@Override
	  public boolean onOptionsItemSelected(MenuItem item) {
	    switch (item.getItemId()) {
	    // action with ID action_refresh was selected
	   
	   
	    case R.id.action_refresh:
	    	Intent in=new Intent(getApplicationContext(),Proflieupdate.class);
	    	in.putExtra("name", username);
	    	in.putExtra("user", lifestyle);
	    	startActivity(in);
	    	
	    default:
	      break;
	    }

	    return true;
	  } 
}
