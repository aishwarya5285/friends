package com.example.friendbook;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Lifes extends Activity {
ImageButton itransaction,imanage,shooping,Booking;
String name;
Button button1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_lifes);
		Intent in=getIntent();
		name=in.getStringExtra("name");
		itransaction=(ImageButton)findViewById(R.id.itransaction);
		imanage=(ImageButton)findViewById(R.id.imanage);
		shooping=(ImageButton)findViewById(R.id.shooping);
		Booking=(ImageButton)findViewById(R.id.Booking);
		button1=(Button)findViewById(R.id.button1);
		itransaction.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in=new Intent(getApplicationContext(),Lifemovies.class);
				
				in.putExtra("name", name);
				in.putExtra("movie","Movies");
				startActivity(in);
				
			}
		});
		imanage.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in=new Intent(getApplicationContext(),LifeMusic.class);
				in.putExtra("name", name);
				in.putExtra("music","Music");
				startActivity(in);
				
			}
		});
		shooping.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in=new Intent(getApplicationContext(),Lifeshoopping.class);
				in.putExtra("name", name);
				in.putExtra("shooping","Shoopping");
				startActivity(in);
				
			}
		});
		Booking.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in=new Intent(getApplicationContext(),LifeBooking.class);
				in.putExtra("name", name);
				in.putExtra("booking","Booking");
				startActivity(in);
				
			}
		});
		button1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in=new Intent(getApplicationContext(),Friendview.class);
				in.putExtra("name", name);
				
				startActivity(in);
			}
		});
	}

	
}
