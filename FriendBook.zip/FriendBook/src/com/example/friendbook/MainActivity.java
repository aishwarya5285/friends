package com.example.friendbook;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity {
	ImageButton login,register;
	ProgressBar pBar;
	int pStatus = 0;
	private Handler handler = new Handler();
	TextView tv;

	ImageView mySplash;
	Context myContext;
	static String myPref_Key="myPrefs";
	SharedPreferences myShared_Prefs;
	Editor myEditor_Data;
	String newVersion;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_main);
	myContext=this;
		

		

	       
		
			try
			{
			   
			    	mySplash=(ImageView)findViewById(R.id.imageView1);
					
					DisplayMetrics outMetrics = new DisplayMetrics();
					MainActivity.this.getWindowManager().getDefaultDisplay().getMetrics(outMetrics);
					TranslateAnimation imageAnimation = new TranslateAnimation(outMetrics.widthPixels, 0, 0, 0);
					imageAnimation.setDuration(1500);

					mySplash.startAnimation(imageAnimation);
					new Thread(new Runnable() {

						
						public void run() {
							// TODO Auto-generated method stub
							while (pStatus <= 100) {

								handler.post(new Runnable() {

									
									public void run() {
//									
									}
								});
								try {

									Thread.sleep(15);

								} catch (InterruptedException e) {
									e.printStackTrace();
								}
								pStatus ++;
							}
							if (pStatus >= 99) {
								
										Intent i = new Intent(getApplicationContext(),Login.class);
										i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
										i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
										
										startActivity(i);
										finish();
									
									
								

							}
							overridePendingTransition(R.anim.ctivityfadein,R.anim.splashfadeout);
							finish();
						}
					}).start();
			       
			    

			}
			catch (Exception e)
			{
			    //No version do something
			}
			
	
		
		

	
		
	}
	private Boolean IsNetworkAvailable(Context aMycontext)
	{
		ConnectivityManager aCmanager = (ConnectivityManager)myContext.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo aNetinfo =aCmanager.getActiveNetworkInfo();

		if(aNetinfo == null || !aNetinfo.isConnected() || !aNetinfo.isAvailable()){
			
			return false;
		}
		return true; 	
	}
	
}

