package com.example.friendbook;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.zip.Inflater;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class Userlist extends BaseAdapter {

	Context mycontext;
	LayoutInflater inf;
	DataBaseHelper sqlite;
	ArrayList<HashMap<String, String>> mylist=new ArrayList<HashMap<String,String>>();
	public Userlist(Context myContext,ArrayList<HashMap<String, String>> mylist1)
	{
		this.mycontext=myContext;
		this.mylist=mylist1;
		sqlite=new DataBaseHelper(mycontext);
		inf=(LayoutInflater)myContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mylist.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return mylist.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) 
	{
		// TODO Auto-generated method stub
		convertView=inf.inflate(R.layout.listviewcontrol, null);
		
		TextView aname=(TextView)convertView.findViewById(R.id.textView3);
		TextView anames=(TextView)convertView.findViewById(R.id.textView4);
		ImageView im=(ImageView)convertView.findViewById(R.id.imageView1);
		
		HashMap<String, String> myhash=new HashMap<String, String>();
		myhash=mylist.get(position);
		aname.setText("Friend Name: "+myhash.get("name").toString());
		String out=myhash.get("pass").toString();
		anames.setText("Life Style :"+out);
		String out1=myhash.get("passing");
		
		byte[] decodedString = Base64.decode(out1, Base64.DEFAULT);
		Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

		im.setImageBitmap(decodedByte);
		return convertView;
	}

	
	
	
}
