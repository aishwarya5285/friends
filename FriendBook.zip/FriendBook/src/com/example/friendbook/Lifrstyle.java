package com.example.friendbook;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

public class Lifrstyle extends Activity {
ImageView im1,im2;
String name;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_lifrstyle);
		Intent in=getIntent();
		name=in.getStringExtra("name");
		im2=(ImageView)findViewById(R.id.imageView2);
		im2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in=new Intent(getApplicationContext(),Lifes.class);
				in.putExtra("name", name);
				startActivity(in);
			}
		});
	}

	
}
