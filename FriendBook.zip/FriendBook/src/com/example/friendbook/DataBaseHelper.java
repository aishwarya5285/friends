package com.example.friendbook;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DataBaseHelper extends SQLiteOpenHelper{
	
	SQLiteDatabase sqlite;
	static String DBName="Friendbook.db";
	static int DBVersion=3;
	static String TBName="regsiter";
	static String TBNamestyle="lifestyle";
	Cursor cursor;

	public DataBaseHelper(Context context) {
		super(context,DBName,null,DBVersion);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		
		db.execSQL("create table "+TBName+"(username text primary key,pass text,mail text,mob text,altermob text,lifestyle text,lifeimage text,lant text,longt text,img text)");
		db.execSQL("create table "+TBNamestyle+"(lifestyle text)");
		// TODO Auto-generated method stub
		
	}

	public void Insert(String name,String pass,String mail,String mob,String altermob,String lant,String longt,String img)
	{
		sqlite=this.getWritableDatabase();
		ContentValues cv=new ContentValues();
		cv.put("username", name);
		cv.put("pass", pass);
		cv.put("mail", mail);
		cv.put("mob", mob);
		cv.put("altermob", altermob);
		cv.put("lant", lant);
		cv.put("longt", longt);
		cv.put("img",img);
		sqlite.insert(TBName, null, cv);
	}
	public void Insertstyle(String name)
	{
		sqlite=this.getWritableDatabase();
		ContentValues cv=new ContentValues();
		cv.put("lifestyle", name);
		
		sqlite.insert(TBNamestyle, null, cv);
	}
	
	public ArrayList<HashMap<String, String>> alist(String lifestyle,String username)
	{
		sqlite=this.getReadableDatabase();
		Cursor c=sqlite.rawQuery("select * from regsiter where username not like '%"+username+"%' and lifeimage='"+lifestyle+"' ", null);
		
		ArrayList<HashMap<String, String>> listdata=new ArrayList<HashMap<String,String>>();
		
		while(c.moveToNext())
		{
			HashMap<String, String> al=new HashMap<String, String>();
			al.put("name", c.getString(c.getColumnIndex("username")).toString());
			al.put("pass", c.getString(c.getColumnIndex("lifestyle")).toString());
			al.put("passing", c.getString(c.getColumnIndex("img")).toString());
			
			listdata.add(al);
		}
		
		return listdata;
		
		
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		
	}

}
