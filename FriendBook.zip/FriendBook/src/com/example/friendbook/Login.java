package com.example.friendbook;


import java.util.Locale;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient.CustomViewCallback;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends Activity {
	EditText txtbox_login_user,txtbox_login_pass;
	Button btn_login,activity_cancel_button;
	TextView login,register,fpass;
	Context contxt;
	Handler handler = new Handler();
	View promptsView,promptsView1;
	SQLiteDatabase db;
	String database="Friendbook.db";
	Cursor cursor;
	String username,password,registers,lifestyle;
	boolean dbfound=true;
	Intent in;
	DataBaseHelper sqlite;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		getActionBar().hide();
		
       contxt = this;
       sqlite=new DataBaseHelper(getApplicationContext());
		sqlite.getWritableDatabase();
		txtbox_login_user=(EditText) findViewById(R.id.txt_login_user);
		txtbox_login_pass=(EditText) findViewById(R.id.txt_login_pass);
		activity_cancel_button=(Button)findViewById(R.id.activity_cancel_button);
		
		register=(TextView)findViewById(R.id.img6);
		
		fpass=(TextView)findViewById(R.id.fpass);
		
		try{
			db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound=true;
			registers="create table if not exists regsiter(username text,password text,repassword text,email text,phone text)";
			db.execSQL(registers);
		}catch(Exception e){
			e.printStackTrace();
			//display("Error DataBase");
		}
		
		register.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intObj = new Intent(getApplicationContext(),Register.class);
				startActivity(intObj);
			}
		});
		btn_login=(Button) findViewById(R.id.btn_login);
		
		btn_login.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				username=txtbox_login_user.getText().toString();
				password=txtbox_login_pass.getText().toString(); 
				  int i=0;
					    if((username.equalsIgnoreCase("admin"))&&(password.equalsIgnoreCase("admin"))){
					    	AddLifestyle();
					    	
					    }else{
					    	
					    	cursor=db.rawQuery("select * from regsiter where username='"+username+"'",null);
							  cursor.moveToFirst();
							
							    while (!cursor.isAfterLast()) {
							
							    String usr=cursor.getString(0);
							    String pas=cursor.getString(1);
							  
							    Log.e("ss",usr+" "+pas);
							   
							    //Toast.makeText(getApplicationContext(), usr,Toast.LENGTH_SHORT).show();
							      cursor.moveToNext();
							    if((username.equalsIgnoreCase(usr))&&(password.equalsIgnoreCase(pas))){
							    	i=1;
							    	
							    }
							    
							    }
							    cursor.close();
							    if(i==1){
							    	Toast.makeText(getApplicationContext(),"Login Successfully",Toast.LENGTH_LONG).show();


							    	in=new Intent(Login.this,Lifrstyle.class);
							    	in.putExtra("name", username);
							    	in.putExtra("user", lifestyle);
							    	startActivity(in);
							   
									    
							    }else{
							    	Toast.makeText(getApplicationContext(),"Login Falid",Toast.LENGTH_LONG).show();
							    }
					    }
				
			}
		});
		activity_cancel_button.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				System.exit(0);
			}
		});
		
		fpass.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Forget();
			}
		});
	}
	
	
	public void Forget() {
		//Log.e("Products", products);
		LayoutInflater li = LayoutInflater.from(Login.this);
		promptsView = li.inflate(R.layout.forgetpass, null);

		final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				Login.this);

		alertDialogBuilder.setView(promptsView);
		final EditText area=(EditText)promptsView.findViewById(R.id.txt_location);
		
		final Button  activityokdialog=(Button)promptsView.findViewById(R.id.activityokdialog);
		final Button activitycanceldialog=(Button)promptsView.findViewById(R.id.activitycanceldialog);
		
		
		final AlertDialog myalertDialog = alertDialogBuilder.create();

			
			// show it
			myalertDialog.show();
			myalertDialog.setCancelable(false);
			myalertDialog.setCanceledOnTouchOutside(false);
		activityokdialog.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

				StrictMode.setThreadPolicy(policy); 
				if(area.getText().toString().length()==10){
					
					
					}else{
						Toast.makeText(getApplicationContext(),"Please Enter valied phonenumber",Toast.LENGTH_SHORT).show();
					}		
			}
		});
		activitycanceldialog.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				myalertDialog.dismiss();
			}
		});
	}
	public void display(String msg) {
		Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
	}

	public void AddLifestyle() {
		//Log.e("Products", products);
		
		
		LayoutInflater li = LayoutInflater.from(Login.this);
		promptsView = li.inflate(R.layout.addlifestyle, null);

		final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				Login.this);

		alertDialogBuilder.setView(promptsView);
		final EditText name=(EditText)promptsView.findViewById(R.id.txt_style);
		

		final Button  activityokdialog=(Button)promptsView.findViewById(R.id.activityokdialog);
		final Button activitycanceldialog=(Button)promptsView.findViewById(R.id.activitycanceldialog);
		final AlertDialog myalertDialog = alertDialogBuilder.create();

		
		// show it
		myalertDialog.show();
		myalertDialog.setCancelable(false);
		myalertDialog.setCanceledOnTouchOutside(false);
		
		
		activityokdialog.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

				StrictMode.setThreadPolicy(policy); 
				if((name.getText().length()!=0))
				{
					
							
					
						 sqlite.Insertstyle(name.getText().toString());
					
						Toast.makeText(getApplicationContext(), "Insert successfully",Toast.LENGTH_SHORT).show();
						
						myalertDialog.dismiss();
						}
						
			    			
					else{
						Toast.makeText(getApplicationContext(),"Please Enter All Values",Toast.LENGTH_SHORT).show();
					}	
		
		}
		});
		activitycanceldialog.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				myalertDialog.dismiss();
			}
		});

		
	}
}
