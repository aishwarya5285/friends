package com.example.friendbook;

import java.util.Locale;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Proflieupdate extends Activity {
	String name,name1,phone,mail,registers,lifestyle;
	EditText txtbox_reg_user,txtbox_reg_mail,txtbox_reg_phone;
	Button btn_reg_register;
	DataBaseHelper sqlite;
	SQLiteDatabase db;
	String database="Friendbook.db";
	boolean dbfound=true;
	Cursor cursor;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_proflieupdate);
		Intent in=getIntent();
		name=in.getStringExtra("name");
		
		lifestyle=in.getStringExtra("user");
		txtbox_reg_user=(EditText)findViewById(R.id.txtbox_reg_user);
		txtbox_reg_phone=(EditText)findViewById(R.id.txtbox_reg_phone);
		txtbox_reg_mail=(EditText)findViewById(R.id.txtbox_reg_mail);
		btn_reg_register=(Button)findViewById(R.id.btn_reg_register);
		try{
			db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound=true;
			registers="create table regsiter(username text primary key,pass text,mail text,mob text,altermob text,lifestyle text,lifeimage text)";
			db.execSQL(registers);
		}catch(Exception e){
			e.printStackTrace();
			//display("Error DataBase");
		}
		cursor=db.rawQuery("select * from regsiter where username='"+name+"'",null);
		  cursor.moveToFirst();
		
		    while (!cursor.isAfterLast()) {
		
		    String usr=cursor.getString(0);
		    String mail=cursor.getString(2);
		    String phone=cursor.getString(3);
		    txtbox_reg_user.setText(usr);
		    txtbox_reg_phone.setText(phone);
		    txtbox_reg_mail.setText(mail);
		    Log.e("User",usr);
		   
		      cursor.moveToNext();
		  
		    
		    }
		    cursor.close();
		    
		    btn_reg_register.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					try{
						db=openOrCreateDatabase(database,SQLiteDatabase.CREATE_IF_NECESSARY,null);
						db.setVersion(1);
						db.setLocale(Locale.getDefault());
						db.setLockingEnabled(true);
						dbfound=true;
						registers="create table regsiter(username text primary key,pass text,mail text,mob text,altermob text,lifestyle text,lifeimage text)";
						db.execSQL(registers);
					}catch(Exception e){
						e.printStackTrace();
						//display("Error DataBase");
					}
				String updateing="update regsiter set username='"+txtbox_reg_user.getText().toString()+"',mail='"+txtbox_reg_mail.getText().toString()+"',mob='"+txtbox_reg_phone.getText().toString()+"' where username='"+name+"' ";
					db.execSQL(updateing);
					
					
					Toast.makeText(getBaseContext(), "Update Successfully",Toast.LENGTH_SHORT).show();
					Intent in=new Intent(getApplicationContext(),Friendview.class);
					in.putExtra("user", lifestyle);
					in.putExtra("name", txtbox_reg_user.getText().toString());
					startActivity(in);
					finish();
				}
			});
	}

	
}
