package com.example.friendbook;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class Register extends Activity {
EditText name,pass,mail,mobileno,altermobile;
RadioGroup myRadio_group;
RadioButton myRadio_Button1,myRadio_Button2,myRadio_Button3,myRadio_Button4;
ImageView img1;
Button b1,b2,b3,bu1;
int REQUEST_ID = 1;
String life,uimg;
RelativeLayout mLinearLayout;
DataBaseHelper sqlite;
SQLiteDatabase db;
String database="Friendbook.db";
boolean dbfound=true;
Cursor cursor;
RadioGroup rg ;
String registers;
int i,j=0;
ArrayList<String> list=new ArrayList<String>();
ArrayList<String> custid=new ArrayList<String>();
LocationManager lm;
double lng;
double late;
String lat;
String provider;
Gpsservice myGpsclass;
protected String latitude,longitude; 
double myLat,myLng;		
protected boolean gps_enabled,network_enabled;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
		sqlite=new DataBaseHelper(getApplicationContext());
		sqlite.getWritableDatabase();
		name=(EditText)findViewById(R.id.activity_profi_custfname);
		pass=(EditText)findViewById(R.id.activity_profi_custlname);
		mail=(EditText)findViewById(R.id.activity_profi_emailid);
		mobileno=(EditText)findViewById(R.id.activity_profi_mobno);
		altermobile=(EditText)findViewById(R.id.activity_profi_altermobno);
		
		bu1=(Button)findViewById(R.id.button1);
		b2=(Button)findViewById(R.id.activityokdialog);
		b3=(Button)findViewById(R.id.activitycanceldialog);
		myGpsclass=new Gpsservice(getApplicationContext());
		img1=(ImageView)findViewById(R.id.imageView2);
		
b2.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		if(name.getText().toString().equals("")&&(pass.getText().toString().equals(""))&&(mail.getText().toString().equals(""))&&(mobileno.getText().toString().equals(""))&&(altermobile.getText().toString().equals(""))){
			Toast.makeText(getApplicationContext(), "Please enter all values?", Toast.LENGTH_SHORT).show();
			
		}else{
			myLat=myGpsclass.Findlatitude();
			myLng=myGpsclass.FindLongitude();
		
			Log.e("request", myLat+"");
			Log.e("reslultcokde", myLng+"");
			sqlite.Insert(name.getText().toString(), pass.getText().toString(), mail.getText().toString(), mobileno.getText().toString(), altermobile.getText().toString(),""+myLat,""+myLng,uimg);
			Toast.makeText(getApplicationContext(), "Register Successfully", Toast.LENGTH_SHORT).show();
			Intent in=new Intent(getApplicationContext(),Login.class);
			startActivity(in);
			finish();
		}
	}
});
b3.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent in=new Intent(getApplicationContext(),Login.class);
		startActivity(in);
		finish();
	}
});
bu1.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {

		
		Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
		photoPickerIntent.setType("image/*");
		startActivityForResult(photoPickerIntent, REQUEST_ID);
	
		
	}
});	
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == RESULT_OK) {
			Log.e("request", requestCode+"");
			Log.e("reslultcokde", RESULT_OK+"");
			Uri uri = data.getData();

			try {
				Bitmap bitmap = MediaStore.Images.Media.getBitmap(
						getContentResolver(), uri);

				img1.setImageBitmap(bitmap);

				ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
				bitmap.compress(Bitmap.CompressFormat.PNG, 50,
						byteArrayOutputStream);
			byte[]	bimgdata = byteArrayOutputStream.toByteArray();
			uimg = Base64.encodeToString(
						bimgdata, Base64.DEFAULT);
				

			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	
}
